package com.example.trabalhosub.Dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.trabalhosub.Helper.SQLiteDataHelper;
import com.example.trabalhosub.Model.Nota;

import java.util.ArrayList;
import java.util.List;

public class NotasDao {
    private SQLiteDataHelper dbHelper;

    public NotasDao(Context context) {
        dbHelper = new SQLiteDataHelper(context);
    }

    // Método para buscar notas de um aluno específico
    public List<Nota> buscarNotasPorAluno(String nomeAluno) {
        List<Nota> listaNotas = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Query SQL corrigida para 4 bimestres
        String query = "SELECT DISCIPLINA, " +
                "SUM(CASE WHEN BIMESTRE = '1ºBim' THEN NOTA ELSE 0 END) AS Nota1, " +
                "SUM(CASE WHEN BIMESTRE = '2ºBim' THEN NOTA ELSE 0 END) AS Nota2, " +
                "SUM(CASE WHEN BIMESTRE = '3ºBim' THEN NOTA ELSE 0 END) AS Nota3, " +
                "SUM(CASE WHEN BIMESTRE = '4ºBim' THEN NOTA ELSE 0 END) AS Nota4, " +
                "(SUM(CASE WHEN BIMESTRE = '1ºBim' THEN NOTA ELSE 0 END) + " +
                " SUM(CASE WHEN BIMESTRE = '2ºBim' THEN NOTA ELSE 0 END) + " +
                " SUM(CASE WHEN BIMESTRE = '3ºBim' THEN NOTA ELSE 0 END) + " +
                " SUM(CASE WHEN BIMESTRE = '4ºBim' THEN NOTA ELSE 0 END)) / 4.0 AS MEDIA " +
                "FROM ALUNO WHERE NOME = ? " +
                "GROUP BY DISCIPLINA";

        Cursor cursor = null;

        try {
            cursor = db.rawQuery(query, new String[]{nomeAluno});

            if (cursor.moveToFirst()) {
                do {
                    String disciplina = cursor.getString(cursor.getColumnIndexOrThrow("DISCIPLINA"));
                    double nota1 = cursor.getDouble(cursor.getColumnIndexOrThrow("Nota1"));
                    double nota2 = cursor.getDouble(cursor.getColumnIndexOrThrow("Nota2"));
                    double nota3 = cursor.getDouble(cursor.getColumnIndexOrThrow("Nota3"));
                    double nota4 = cursor.getDouble(cursor.getColumnIndexOrThrow("Nota4"));
                    double media = cursor.getDouble(cursor.getColumnIndexOrThrow("MEDIA"));

                    Nota nota = new Nota(disciplina, nota1, nota2, nota3, nota4, media);
                    listaNotas.add(nota);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }

        return listaNotas;
    }
}
