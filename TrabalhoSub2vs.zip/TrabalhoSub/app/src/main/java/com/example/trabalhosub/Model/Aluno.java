package com.example.trabalhosub.Model;

public class Aluno {
    private int ra;
    private String nome;
    private int nota;
    private String disciplina;
    private String bimestre;

    public Aluno() {}

    public String getDisciplina(){
        return disciplina;
    }
    public void setDisciplina(String disciplina){
        this.disciplina = disciplina;

    }

    public String getBimestre(){
        return bimestre;
    }
    public void setBimestre(String bimestre){
        this.bimestre = bimestre;
    }


    public int getRa(){
        return ra;
    }

    public void setRa(int ra){
        this.ra = ra;
    }

    public String getNome(){
        return nome;
    }

    public void setNome(String Nome){
        this.nome = nome;
    }

    public int getNota(){
        return nota;
    }
    public void setNota(int nota){
        this.nota = nota;        
    }

}

