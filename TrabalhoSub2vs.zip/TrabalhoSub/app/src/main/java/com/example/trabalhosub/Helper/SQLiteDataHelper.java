package com.example.trabalhosub.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

public class SQLiteDataHelper extends SQLiteOpenHelper {
    public SQLiteDataHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    private static final String DATABASE_NAME = "banco.db";
    private static final int DATABASE_VERSION = 3;

    public SQLiteDataHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(
                "CREATE TABLE ALUNO (" +
                        "RA INTEGER, " +
                        "NOME VARCHAR(100), " +
                        "DISCIPLINA VARCHAR(100), " +
                        "NOTA FLOAT, " +
                        "NOTA1 FLOAT," +
                        "NOTA2 FLOAT," +
                        "NOTA3 FLOAT," +
                        "BIMESTRE VARCHAR(20)," +
                        "PRIMARY KEY(RA, BIMESTRE))");

        sqLiteDatabase.execSQL(
                "CREATE TABLE DISCIPLINA (" +
                        "ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "NOME VARCHAR(100))");

        // Criar tabela BIMESTRE
        sqLiteDatabase.execSQL(
                "CREATE TABLE BIMESTRE (" +
                        "ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "NOME VARCHAR(20))");

        // Inserir valores estáticos na tabela DISCIPLINA
        sqLiteDatabase.execSQL("INSERT INTO DISCIPLINA (NOME) VALUES ('Engenharia')");
        sqLiteDatabase.execSQL("INSERT INTO DISCIPLINA (NOME) VALUES ('Design')");
        sqLiteDatabase.execSQL("INSERT INTO DISCIPLINA (NOME) VALUES ('Programação')");

        // Inserir valores estáticos na tabela BIMESTRE
        sqLiteDatabase.execSQL("INSERT INTO BIMESTRE (NOME) VALUES ('1ºBim')");
        sqLiteDatabase.execSQL("INSERT INTO BIMESTRE (NOME) VALUES ('2ºBim')");
        sqLiteDatabase.execSQL("INSERT INTO BIMESTRE (NOME) VALUES ('3ºBim')");
        sqLiteDatabase.execSQL("INSERT INTO BIMESTRE (NOME) VALUES ('4ºBim')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        // Atualização do banco de dados
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS ALUNO");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS DISCIPLINA");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS BIMESTRE");
        onCreate(sqLiteDatabase);

    }

    // Método para inserir dados na tabela ALUNO
    public boolean insertData(String ra, String nome, String disciplina, double nota, String bimestre) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        // Adicionando os dados ao ContentValues
        contentValues.put("RA", ra);
        contentValues.put("NOME", nome);
        contentValues.put("DISCIPLINA", disciplina);
        contentValues.put("NOTA", nota);

        contentValues.put("BIMESTRE", bimestre);

        // Inserindo os dados no banco
        long result = db.insert("ALUNO", null, contentValues);

        // Verifica se a inserção foi bem-sucedida
        db.close();
        return result != -1;
    }
}
