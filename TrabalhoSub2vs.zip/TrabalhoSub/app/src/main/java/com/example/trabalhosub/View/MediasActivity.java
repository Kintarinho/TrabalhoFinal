package com.example.trabalhosub.View;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.trabalhosub.Adapter.MediaAdapter;
import com.example.trabalhosub.Helper.SQLiteDataHelper;
import com.example.trabalhosub.R;

import java.util.ArrayList;
import java.util.List;

public class MediasActivity extends AppCompatActivity {

    private Spinner spDisciplina;
    private RecyclerView rvMedias;
    private SQLiteDataHelper databaseHelper;
    private MediaAdapter mediaAdapter;
    private List<String> listaMedias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medias);


        spDisciplina = findViewById(R.id.spDisciplina);
        rvMedias = findViewById(R.id.rvMedias);
        databaseHelper = new SQLiteDataHelper(this);

        // Configura o RecyclerView
        rvMedias.setLayoutManager(new LinearLayoutManager(this));
        listaMedias = new ArrayList<>();
        mediaAdapter = new MediaAdapter(listaMedias);
        rvMedias.setAdapter(mediaAdapter);

        carregarDisciplinas();

        // Configura o Listener do Spinner para buscar médias ao selecionar uma disciplina
        spDisciplina.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                buscarMedias(); // Chama o método para buscar as médias filtradas
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Não faz nada
            }
        });


        buscarMedias();
    }


    private void carregarDisciplinas() {
        List<String> disciplinas = new ArrayList<>();
        disciplinas.add("Engenharia de Software");
        disciplinas.add("Design");
        disciplinas.add("Programação");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, disciplinas);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDisciplina.setAdapter(adapter);
    }

    // Método para buscar médias no banco de dados filtradas por disciplina
    private void buscarMedias() {
        listaMedias.clear(); // Limpa a lista antes de recarregar

        // Pega a disciplina selecionada no Spinner
        String disciplinaSelecionada = spDisciplina.getSelectedItem().toString();

        // Query para buscar médias filtradas pela disciplina
        String query = "SELECT NOME, BIMESTRE, AVG(NOTA1 + NOTA2 + NOTA3)/3 AS MEDIA FROM ALUNO " +
                "WHERE DISCIPLINA = ? " +
                "GROUP BY NOME, BIMESTRE"; // Agrupa por nome e bimestre

        Cursor cursor = databaseHelper.getReadableDatabase().rawQuery(query, new String[]{disciplinaSelecionada});

        if (cursor.moveToFirst()) {
            do {
                String nomeAluno = cursor.getString(cursor.getColumnIndexOrThrow("NOME"));
                String bimestre = cursor.getString(cursor.getColumnIndexOrThrow("BIMESTRE"));
                double media = cursor.getDouble(cursor.getColumnIndexOrThrow("MEDIA"));

                listaMedias.add(nomeAluno + " - " + bimestre + ": " + String.format("%.2f", media));
            } while (cursor.moveToNext());
        }


        mediaAdapter.notifyDataSetChanged();
    }
}
