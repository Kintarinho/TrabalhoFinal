package com.example.trabalhosub.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.trabalhosub.R;

import java.util.List;

public class NotasAdapter extends RecyclerView.Adapter<NotasAdapter.NotasViewHolder> {

    private List<String> listaNotas;

    public NotasAdapter(List<String> listaNotas) {
        this.listaNotas = listaNotas;
    }

    @NonNull
    @Override
    public NotasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_nota, parent, false);
        return new NotasViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotasViewHolder holder, int position) {
        String nota = listaNotas.get(position);
        holder.tvNota.setText(nota);
    }

    @Override
    public int getItemCount() {
        return listaNotas.size();
    }

    public static class NotasViewHolder extends RecyclerView.ViewHolder {
        TextView tvNota;

        public NotasViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNota = itemView.findViewById(R.id.tvNota);
        }
    }
}
