package com.example.trabalhosub.View;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.trabalhosub.Adapter.NotasAdapter;
import com.example.trabalhosub.Helper.SQLiteDataHelper;
import com.example.trabalhosub.R;

import java.util.ArrayList;
import java.util.List;

public class NotasActivity extends AppCompatActivity {

    private Spinner spAluno;
    private RecyclerView rvNotas;
    private SQLiteDataHelper databaseHelper;
    private NotasAdapter notasAdapter;
    private List<String> listaNotas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notas);

       spAluno = findViewById(R.id.spAluno);
        rvNotas = findViewById(R.id.rvNotas);
        databaseHelper = new SQLiteDataHelper(this);


        rvNotas.setLayoutManager(new LinearLayoutManager(this));
        listaNotas = new ArrayList<>();
        notasAdapter = new NotasAdapter(listaNotas);
        rvNotas.setAdapter(notasAdapter);

        carregarAlunos();

        // Listener para buscar as notas ao selecionar um aluno
        spAluno.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                buscarNotas();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Não faz nada,
                // Inserido pelo ChatGPT, fez o código rodar sem erro :/
            }
        });
    }

    // Método para carregar os alunos no Spinner
    private void carregarAlunos() {
        List<String> alunos = new ArrayList<>();

        Cursor cursor = databaseHelper.getReadableDatabase().rawQuery(
                "SELECT DISTINCT NOME FROM ALUNO", null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    String nomeAluno = cursor.getString(cursor.getColumnIndexOrThrow("NOME"));
                    alunos.add(nomeAluno);
                } while (cursor.moveToNext());
            }
            cursor.close();
        }

        if (alunos.isEmpty()) {
            Toast.makeText(this, "Nenhum aluno encontrado!", Toast.LENGTH_SHORT).show();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, alunos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spAluno.setAdapter(adapter);
    }

    // Método para buscar as notas do aluno selecionado
    private void buscarNotas() {
        listaNotas.clear();

        String alunoSelecionado = spAluno.getSelectedItem().toString();

        Cursor cursor = databaseHelper.getReadableDatabase().rawQuery(
                "SELECT DISCIPLINA, NOTA1, NOTA2, NOTA3, " +
                        "((NOTA1 + NOTA2 + NOTA3) / 3.0) AS MEDIA " +
                        "FROM ALUNO WHERE NOME = ?", new String[]{alunoSelecionado});

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    String disciplina = cursor.getString(cursor.getColumnIndexOrThrow("DISCIPLINA"));
                    double nota1 = cursor.getDouble(cursor.getColumnIndexOrThrow("NOTA1"));
                    double nota2 = cursor.getDouble(cursor.getColumnIndexOrThrow("NOTA2"));
                    double nota3 = cursor.getDouble(cursor.getColumnIndexOrThrow("NOTA3"));
                    double media = cursor.getDouble(cursor.getColumnIndexOrThrow("MEDIA"));

                    listaNotas.add(disciplina + " - " +
                            String.format("%.1f", nota1) + " | " +
                            String.format("%.1f", nota2) + " | " +
                            String.format("%.1f", nota3) + " | " +
                            String.format("%.1f", media));
                } while (cursor.moveToNext());
            } else {
                Toast.makeText(this, "Nenhuma nota encontrada para o aluno!", Toast.LENGTH_SHORT).show();
            }
            cursor.close();
        }

        notasAdapter.notifyDataSetChanged();
    }
}
