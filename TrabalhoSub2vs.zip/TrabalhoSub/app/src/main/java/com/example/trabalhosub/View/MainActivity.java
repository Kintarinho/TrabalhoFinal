package com.example.trabalhosub.View;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.trabalhosub.Helper.SQLiteDataHelper;
import com.example.trabalhosub.R;

public class MainActivity extends AppCompatActivity {

    private EditText edRa;
    private EditText edNome;
    private Spinner spDisci;
    private EditText edNota;
    private Spinner spBim;
    private Button btAdc;
    private Button btVerNotas;
    private Button btVerMedias;
    private SQLiteDataHelper databaseHelper;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edRa = findViewById(R.id.edRa);
        edNome = findViewById(R.id.edNome);
        spDisci = findViewById(R.id.spDisci);
        edNota = findViewById(R.id.edNota);
        spBim = findViewById(R.id.spBim);
        btAdc = findViewById(R.id.btAdc);
        btVerNotas = findViewById(R.id.btVerNotas);
        btVerMedias = findViewById(R.id.btVerMedias);
        // Dentro do onCreate()
        String[] disciplinas = {"Design", "Engenharia de Software", "Programação"};
        String[] bimestres = {"1º Bimestre", "2º Bimestre", "3º Bimestre", "4º Bimestre"};

        ArrayAdapter<String> adapterDisciplinas = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, disciplinas);
        adapterDisciplinas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDisci.setAdapter(adapterDisciplinas);

        ArrayAdapter<String> adapterBimestres = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, bimestres);
        adapterBimestres.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBim.setAdapter(adapterBimestres);

        databaseHelper = new SQLiteDataHelper(this, "banco.db", null, 3);

        btAdc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String Ra = edRa.getText().toString();
            String Nome = edNome.getText().toString();

            String notaStr = edNota.getText().toString();String Disciplina = spDisci.getSelectedItem().toString(); // Obtém a disciplina selecionada
                String Bimestre = spBim.getSelectedItem().toString(); // Obtém o bimestre selecionado


                if (Ra.isEmpty() || Nome.isEmpty() ||  Disciplina.isEmpty() || notaStr.isEmpty() || Bimestre.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    double Nota = Double.parseDouble(notaStr);
                    boolean isInserted = databaseHelper.insertData(Ra, Nome, Disciplina, Nota, Bimestre);

                    if (isInserted) {
                        Toast.makeText(MainActivity.this, "Dados adicionados com sucesso!", Toast.LENGTH_SHORT).show();

                        // Limpar os campos após adicionar
                        edRa.setText("");
                        edNome.setText("");
                        edNota.setText("");
                        spDisci.setSelection(0);
                        spBim.setSelection(0);
                    } else {
                        Toast.makeText(MainActivity.this, "Erro ao adicionar os dados", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Nota inválida", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btVerNotas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, NotasActivity.class);
                startActivity(intent);
            }
        });


        btVerMedias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MediasActivity.class);
                startActivity(intent);
            }
        });
    }
}
